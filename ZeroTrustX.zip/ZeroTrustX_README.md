# ZeroTrustX

**Advanced Zero Trust Access Evaluation, Policy Analysis & Continuous Security Verification Platform**

A 6-month cybersecurity industrial training project. Offline-first, database-free, single-command Flask application that evaluates synthetic access requests through RBAC, ABAC, a configurable policy engine, and a deterministic risk engine -- producing explainable ALLOW / DENY / STEP-UP / REVIEW decisions.

---

## 1. Project Overview

Most access-control demos boil down to "does this user's role match this resource -- yes or no." That's not really how a Zero Trust system is supposed to work. ZeroTrustX evaluates every access request against *multiple independent signals at once* -- identity, device posture, resource sensitivity, network zone, time of day, MFA status -- runs them through both a priority-ordered policy engine and a separately-computed risk score, and only then produces a decision. Critically, the two engines don't always agree, and when they don't, the system takes the *stricter* outcome. That single design choice is what makes this a Zero Trust system rather than a glorified permission table: a request the policy engine would allow can still get escalated to REVIEW if the independently-computed risk score says otherwise.

## 2. Problem Statement

Traditional access control checks identity once, at login, and then trusts the session for its duration. That model breaks down the moment context changes mid-session -- a stolen laptop, a network switch to an untrusted hotspot, MFA that quietly expired. Zero Trust's answer is "never trust, always verify": every request gets evaluated on its own merits, using whatever context is available *right now*, not what was true when the user logged in an hour ago.

## 3. Objectives

- Demonstrate RBAC and ABAC working together rather than as competing models
- Build a policy engine with real priority ordering and conflict detection, not just a rule list
- Score risk deterministically and explainably -- every point on the 0-100 scale traces to a named factor
- Simulate continuous verification (a session that gets re-evaluated when context changes mid-session)
- Provide a least-privilege analyzer, security findings, case management, and audit logging
- Do all of this offline, without a database, and with a single startup command

## 4. Zero Trust Principles Demonstrated

- **Never trust automatically** -- absence of an explicit ALLOW policy is a DENY, not a pass-through
- **Least privilege** -- the Least Privilege Analyzer compares what a user actually accessed against their role's RBAC grant
- **Continuous verification** -- the Continuous Verification simulator re-evaluates an active session when network/MFA context changes
- **Explainable decisions** -- every decision returns its risk factors, matched/failed policies, and a human-readable recommendation; nothing is ever a bare "ACCESS DENIED"
- **Defense in depth** -- the policy engine and risk engine are evaluated independently, and the stricter result wins (see section 9 below for a concrete example)

## 5. Features

- 23 functional modules: dashboard, identity/device/resource/role management, policy engine, access simulator, risk engine, context evaluation, least-privilege analyzer, policy conflict detector, continuous verification, access graph (NetworkX), policy simulator, what-if analysis, investigation workspace, audit log, security findings, report generator (PDF/JSON/CSV), configuration manager, system health, and a pytest test suite
- JSON-file storage only -- no database of any kind
- Deterministic, explainable risk scoring (never random)
- A working policy conflict detector that finds genuinely overlapping/contradictory policies

## 6. Architecture

```
ACCESS REQUEST -> REQUEST VALIDATION -> IDENTITY EVALUATION
      -> [USER ROLE | DEVICE TRUST | RESOURCE SENSITIVITY] (parallel)
      -> NETWORK CONTEXT -> TIME CONTEXT -> MFA STATUS
      -> SECURITY POLICIES (policy engine) -> RISK ENGINE
      -> POLICY EVALUATION -> [ALLOW | DENY | STEP-UP | REVIEW]
      -> AUDIT LOG -> EXPLAINABLE DECISION
```

The policy engine and risk engine run independently against the same attribute bag (built by the ABAC layer from RBAC + device + resource + context signals). The final decision is the *stricter* of the two -- see `app/access/decision.py`.

## 7. Technology Stack

| Layer | Technology |
|---|---|
| Backend | Python 3.11+, Flask |
| Frontend | HTML5, CSS3, vanilla JavaScript |
| Data | JSON (data/ for seed data, storage/ for runtime state) |
| Visualization | Chart.js (vendored locally under `static/vendor/`, not CDN-loaded -- this app is offline-first) |
| Graph | NetworkX |
| Testing | pytest (71 tests, all passing) |
| Reports | ReportLab (PDF), stdlib json/csv |

No database of any kind is used. No API keys. No cloud services.

## 8. Requirements

- Python 3.10 or later (3.11+ recommended)
- pip (for first-run dependency installation)
- ~50 MB free disk space

## 9. Installation

Clone or extract the project, then from the project root:

**Windows:**
```
python run.py
```

**Linux / macOS:**
```
python3 run.py
```

That's it. `run.py` checks your Python version, installs any missing dependencies (`Flask`, `networkx`, `reportlab`, `pytest`) via pip, creates the `storage/` and `reports/` directories if they don't exist, initializes runtime JSON files, and starts the Flask development server on `http://127.0.0.1:5000`.

No manual configuration, no database setup, no API keys.

## 10. Demo Workflow

1. Open `http://127.0.0.1:5000` -- the dashboard is empty until you evaluate some requests
2. Go to **Access Simulator**, pick a user/device/resource/context combination, click **EVALUATE ACCESS**
3. Watch the decision banner, risk score breakdown, and matched policy appear
4. Try a few different combinations -- an untrusted device against a critical resource, a request outside business hours, missing MFA on a sensitive resource
5. Visit **Policies** to see the priority-ordered rule set and any detected conflicts
6. Visit **Findings** and click **RUN FINDINGS SCAN** to generate anomaly findings from your request history
7. Visit **Least Privilege** to see RBAC-vs-observed-access comparison
8. Visit **Reports** to generate a PDF/JSON/CSV assessment report from whatever you've evaluated so far

For a scripted run of 12+ predefined scenarios (useful for grading/demo purposes), run:

```
python3 run_scenarios.py
```

This exercises the simulator, continuous verification, findings scan, conflict detector, and dashboard through the exact same code paths as the running server, and prints real output for each.

## 11. Policy Simulator

The Access Simulator lets you pick a user, device, resource, network zone, MFA status, action, and time, then evaluates the request through RBAC, the policy engine, and the risk engine in one call. The result panel shows the final decision, the 0-100 risk score with its contributing factors, the decisive policy (if any), and a recommendation.

## 12. Risk Engine

Risk is computed deterministically from named, weighted factors (resource sensitivity, device trust, network zone, MFA status, access time, RBAC role mismatch, user account status, user baseline risk) plus a bonus if the final policy action is DENY. Every point is traceable -- there is no randomness anywhere in the scoring. See `app/risk/engine.py`.

## 13. Investigation Workflow

Findings generated by the anomaly scanner (or manually) can be attached to a Case in the Investigation Workspace, where an analyst can add notes and track status through OPEN -> INVESTIGATING -> RESOLVED -> CLOSED.

## 14. Report Generation

The Reports page generates:
- A PDF security assessment report (executive summary, risk table, least-privilege findings, policy conflicts, security findings, recommendations, and limitations) via ReportLab
- A full JSON export of dashboard stats, requests, findings, conflicts, and least-privilege results
- A CSV export of request history

All three pull live from whatever's currently in `storage/`, so the report always reflects real evaluated data -- it will not generate content for requests that haven't actually been run.

## 15. Testing

```
python3 -m pytest tests/ -v
```

71 tests across 8 files covering: app startup, JSON initialization, seed data loading, RBAC, ABAC, access request validation, the policy engine (condition evaluation, priority ordering, conflict detection), device trust / time / network / MFA context evaluation, risk scoring, decision generation, least-privilege analysis, continuous verification, the access graph, findings generation and deduplication, case management, audit logging, PDF/JSON/CSV report generation, and security controls (path traversal protection, input validation). All 71 currently pass.

## 16. Troubleshooting

- **"Missing dependencies" errors on startup**: run.py should install them automatically via pip; if your environment blocks pip, run `pip install -r requirements.txt` manually first.
- **Port 5000 already in use**: edit `config.json` -> `app.port` and restart.
- **Charts not appearing on the dashboard**: Chart.js is vendored locally under `static/vendor/chart.umd.min.js` and loaded from there -- if you moved/renamed that file, dashboard charts will silently fail to render (everything else on the page still works).
- **Findings/dashboard look empty**: the app ships with seed identities/devices/resources/policies but *no* request history -- evaluate a few requests via the Access Simulator first, or run `python3 run_scenarios.py`.

## 17. Security Limitations

This is a demonstration/training project, not a production access-control system:
- No real authentication -- MFA status, network zone, etc. are simulator inputs, not verified signals
- The policy conflict detector is a heuristic (field/value overlap check), not a formal constraint solver -- it surfaces *candidate* conflicts for analyst review, not proven ones
- The Flask development server is used directly; a production deployment would need a WSGI server behind it
- All identities, devices, and resources are synthetic

## 18. Ethical Use

This project is intended for educational, portfolio, and training purposes. It does not perform real network scanning, real authentication, or interact with any live infrastructure. Do not point request fields at real credentials or real systems.

## 19. Project Structure

```
ZeroTrustX/
├── app/
│   ├── routes/        Flask blueprints (16 route modules)
│   ├── models/         repository.py (data access), request_store.py
│   ├── policy/          engine.py (condition evaluation, priority resolution)
│   ├── risk/             engine.py (deterministic risk scoring)
│   ├── access/          rbac.py, abac.py, context.py, decision.py, continuous.py
│   ├── analysis/        least_privilege.py, conflicts.py, graph.py, findings.py, cases.py
│   ├── reporting/       stats.py, report.py (PDF/JSON/CSV)
│   └── utils/            storage.py, bootstrap.py, audit.py, health.py
├── templates/           16 Jinja2 page templates + base.html
├── static/
│   ├── css/style.css
│   ├── js/
│   └── vendor/chart.umd.min.js   (vendored, not CDN-loaded)
├── data/                 users.json, devices.json, resources.json, roles.json, policies.json
├── storage/              runtime state: requests, findings, cases, sessions, audit.log
├── reports/              generated PDF/JSON/CSV output
├── screenshots/          captured application screenshots
├── tests/                71 pytest tests across 8 files
├── config.json
├── requirements.txt
├── run.py
├── run_scenarios.py     scripted demonstration run
├── README.md
└── USER_MANUAL.md
```

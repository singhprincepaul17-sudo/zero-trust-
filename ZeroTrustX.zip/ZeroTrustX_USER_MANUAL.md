# ZeroTrustX -- User Manual

Step-by-step guide to running and using ZeroTrustX.

## 1. Install Python

You need Python 3.10 or later. Check your version:

```
python3 --version
```

If you're on Windows and don't have Python, get it from python.org and make sure "Add Python to PATH" is checked during installation.

## 2. Start the Application

From the project's root folder:

**Windows:** `python run.py`
**Linux/macOS:** `python3 run.py`

The first run installs missing dependencies automatically. You'll see:

```
[ZeroTrustX] Python version OK: 3.x.x
[ZeroTrustX] All required dependencies already installed.
[ZeroTrustX] Required directories present.
[ZeroTrustX] Initialized runtime storage: ...
[ZeroTrustX] Starting Flask application on http://127.0.0.1:5000
```

Leave this terminal window open -- it's running the server. Press CTRL+C to stop it.

## 3. Open the Dashboard

Open `http://127.0.0.1:5000` in a browser. On a fresh install this will show all-zero stats -- that's expected, since no access requests have been evaluated yet.

## 4. Review Users (Identities page)

The sidebar's **Identities** link shows all 12 synthetic users, their department, role, and status. These are the identities you'll pick from when building access requests.

## 5. Review Devices

**Devices** shows each device's compliance/encryption/agent status alongside two trust values: the stored `trust_level` label, and the *evaluated* trust the device-trust engine independently derives from the raw attributes. They usually agree; when they don't, that's worth noting -- it means the stored label is stale.

## 6. Review Resources

**Resources** lists all 9 classified resources with their sensitivity level (PUBLIC through CRITICAL), owning department, and required roles.

## 7. Review Policies

**Policies** shows every policy sorted by priority, with its action, status, and conditions. If any policies overlap in a way that could produce contradictory outcomes, a warning panel appears at the top explaining exactly which policies conflict and why.

## 8. Create an Access Request

Go to **Access Simulator**. Pick:
- A **User**
- A **Device**
- A **Resource**
- The **Action** (READ / WRITE / DELETE / ADMIN)
- The **Network Zone** the request is coming from
- The **MFA Status**
- The **Request Time**

## 9. Evaluate the Request

Click **EVALUATE ACCESS**. The result panel updates with:
- The final decision (ALLOW / DENY / STEP-UP / REVIEW), color-coded
- The risk score out of 100 and its classification
- Every contributing risk factor and its point value
- The full list of reasons behind the decision
- The decisive policy, if one applied
- A plain-language recommendation

## 10. Review Risk

The risk breakdown under the decision banner shows exactly which factors added points -- resource sensitivity, device trust, network zone, MFA status, access time, RBAC mismatch, account status, and baseline risk. Nothing is random; the same inputs always produce the same score.

## 11. Review Policy Decisions

The **Policies** page lets you toggle any policy between ACTIVE and INACTIVE to see how it changes future evaluations -- useful for understanding why a particular request got the decision it did.

## 12. Perform What-If Analysis

Go to **What-If Analysis**. Set up a base request, then change just the network zone or MFA status and click **COMPARE**. You'll see the before/after decision and risk side by side, plus exactly which fields changed.

## 13. Run Continuous Verification

Go to **Continuous Verification**. Click **START SESSION** with a user/device/resource. Then use **Apply Context Change** to simulate the network dropping to untrusted or MFA lapsing mid-session -- the timeline below shows each re-evaluation and whether the session should continue, step up, or be denied.

## 14. Review the Access Graph

**Access Graph** visualizes User -> Role -> Device -> Policy -> Resource -> Decision relationships from your request history as a node graph. Any users who reach a DENY outcome through multiple distinct paths are flagged above the graph.

## 15. Review Findings

**Findings** lists anomaly indicators generated from your request history. Click **RUN FINDINGS SCAN** to generate fresh findings (already-open findings with the same title won't be duplicated). Each finding can be marked OPEN / REVIEWED / RESOLVED / FALSE_POSITIVE.

## 16. Create a Case

Go to **Investigation**. Fill in a title and priority, click **CREATE CASE**. Cases track through OPEN -> INVESTIGATING -> RESOLVED -> CLOSED.

## 17. Add Analyst Notes

On any case card, type into the notes box and click **ADD NOTE**. Notes are timestamped and kept in order.

## 18. Generate a Report

Go to **Reports**. Click **GENERATE PDF REPORT** for a full assessment document, or **EXPORT JSON** / **EXPORT CSV** for raw data. Generated files appear in the table below with a download link. Reports reflect exactly what's in your request history at the moment you generate them -- evaluate some requests first if the report looks empty.

---

## Quick Reference: Decision Meanings

| Decision | Meaning |
|---|---|
| **ALLOW** | Request satisfies policy and risk thresholds |
| **DENY** | Request should not be granted under current context |
| **STEP-UP** | Additional verification (re-auth/MFA challenge) needed before granting |
| **REVIEW** | Route to a security analyst for manual review |

## Quick Reference: Risk Classification

| Score | Classification |
|---|---|
| 0-24 | LOW |
| 25-49 | MEDIUM |
| 50-74 | HIGH |
| 75-100 | CRITICAL |
